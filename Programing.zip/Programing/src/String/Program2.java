package String;

public class Program2 {
	public static void main(String[] args) {
		String s=new String("Manmohan");
		System.out.println(s);
		String s1=new String("Manmohan");
		System.out.println(s==s1);
		System.out.println(s.equals(s1));
	}
		
		
}
