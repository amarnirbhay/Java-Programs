package String;

public class Program1 {
	public static void main(String[] args) {
		String s="Manmohan Singh";
		System.out.println(s);
		String s1="Manmohan Singh";
		System.out.println(s==s1);
		String s2="manmohan Singh";
		System.out.println(s1==s2);
	}
}
