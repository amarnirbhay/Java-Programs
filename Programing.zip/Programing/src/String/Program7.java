package String;

public class Program7 {
	// index of method
	public static void main(String[] args) {
		String s="java is a Programing language";
		System.out.println(s.indexOf("is"));
	}
}
