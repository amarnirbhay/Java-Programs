package String;

public class Program13 {
	// Compare to Method
	public static void main(String[] args) {
		
		String s="ManMohan";
		String s1="Amar";
		System.out.println(s.compareTo(s1));
		String s2="Ankit";
		System.out.println(s1.compareTo(s2));
		String s3="Ankit";
		System.out.println(s2.compareTo(s3));
	}

}
