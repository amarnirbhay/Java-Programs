package String;

public class Program3 {
		public static void main(String[] args) {
			
			String s="Java is a programing Language";
			
			String s1[]=s.split(" ");
			
			for (String s2 : s1) {
				System.out.println(s2);
			}
				{
			}
		}
}
