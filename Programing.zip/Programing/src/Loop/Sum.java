package Loop;

public class Sum {
	public static void main(String[] args) {
		int sum=0;
		int i=50;
		
		while(i<=100)
		{
			sum=sum+i;
			i++;
			
		}
		System.out.println("Sum is :"+sum);
	}	

}
