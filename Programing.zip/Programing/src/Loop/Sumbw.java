package Loop;

public class Sumbw {
	public static void main(String[] args) {
		
		int sum=0;
		int a=9;
		
		
		System.out.println();
	}

}
