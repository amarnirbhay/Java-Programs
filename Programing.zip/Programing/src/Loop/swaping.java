package Loop;

public class swaping {
		public static void main(String[] args) {
			int a=20;
			int  b=30;
			
			System.out.println(a+" Before Swapping "+b);
			int temp=a;
			a=b;
			b=temp;
			System.out.println(a+" After Swwapping "+b);
		}

}
