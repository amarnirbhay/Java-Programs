package Loop;

public class Evenprint {
	public static void main(String[] args) {
		int num=100;
		System.out.println("List of Even Number between one to Hundred:");
		for(int i=1;i<=num;i++)
	
	if(i%2==0)
	{
		System.out.print(i+" ");
	}

	}
	}
