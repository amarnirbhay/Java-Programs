package TwoDArray;

public class Program1 {
	
	public static void main(String[] args) {
int ar[][]= {{2,11,1},{12,10}};
		
		for (int i = 0; i< ar.length;i++) {
			
			for(int j=0; j< ar[i].length; j++) {
				
				System.out.println(ar[i][j]);
			}
		}
	}
		
}
