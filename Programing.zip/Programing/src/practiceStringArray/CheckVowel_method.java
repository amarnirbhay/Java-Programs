package practiceStringArray;

public class CheckVowel_method {
	
	public static void main(String[] args) {
		 
	
		
	}
	public void checkvowel(char y) {
		
	}

}
