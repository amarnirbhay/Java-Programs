package practiceStringArray;

public class StringinArray {
	public static void main(String[] args) {
		//Converting a String to Character Array
		String x="Amit";
		char a[]=x.toCharArray();
		
		
		for (char c : a) {
			System.out.print(c);
		}
		
		
	}

}
