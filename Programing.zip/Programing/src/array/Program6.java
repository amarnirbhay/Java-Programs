package array;

public class Program6 {
		public static void main(String[] args) {
			int ar[]= {10,20,30,14};
			int count = 0; //for count the array element
			for (int i : ar) {
				count++;
				System.out.println(i);
				
			}
			System.out.println(count);
			}
}
