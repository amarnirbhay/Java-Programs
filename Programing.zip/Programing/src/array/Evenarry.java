package array;

public class Evenarry {
	public static void main(String[] args) {
		int ar[]= {21,30,12,14};
		
		for(int i=0; i< ar.length;i++)
		{
		if(ar[i]%2==0)
			System.out.println(ar[i]+" ");
	}
	}

}
