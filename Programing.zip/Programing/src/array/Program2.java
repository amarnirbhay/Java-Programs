package array;

public class Program2 {
	public static void main(String[] args) {
		String ar[]= {"10","20","30","40","50"};
		
		for(int i=0;i<ar.length;i++)
		{
			System.out.println(ar);
			
			System.out.print(ar[i]+" "); //use to print the given arrsy values
			
		}
		
	
	}
}
