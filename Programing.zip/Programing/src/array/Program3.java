package array;

public class Program3 {
	public static void main(String[] args) {
		
	
		int ar[]= new int[4];
		
		ar[0]=20;
		ar[2]=30;
		
		for(int i= 0; i< ar.length; i++)
		{
			System.out.println(ar[i]);
		}
			
}
}
