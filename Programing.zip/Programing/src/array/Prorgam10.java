package array;
public class Prorgam10 {
	public static void main(String[] args) {
		int ar[]= {20,40,39,43,2};
		for(int i=0; i< ar.length; i++) {
		if(i%2==0)
		{
			System.out.println(ar[i]+" "+i);
		}
		}
	}
}
